package controlador;

public enum CategoriasEnum {
	FiccionLiteraria,
    NoFiccion,
    MisterioThriller,
    CienciaFiccion,
    Fantasia,
    Romance,
}
