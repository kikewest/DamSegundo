/**
 * 
 */
/**
 * @author kike_
 *
 */
module tresEnRaya {
	requires java.desktop;
}