This example shows how you can use experimental RELAX NG support.

Please be warned that this feature is experimental, and therefore
not suitable for the production purpose. A future version of JAXB RI
can change the way it handles RELAX NG, or even drop the support for it.

That said, everything is basically the same as XML Schema ---
except that you are using RELAX NG as the source schema.

See http://relaxng.org/ for more information about RELAX NG.