package xml;

import javax.xml.parsers.ParserConfigurationException;
public class Principal {

	public static void main(String[] args) throws ParserConfigurationException {	
		
//		LeerXML2.Leer();
//		NumEspectadores.NumEspec();
//      ModificarTitulo.modificarNombreAnimePorCodigo();
//		//porcentajeAudiencia.NumEspec();
//		CrearXML.crearXML();
//		 // Leer el archivo XML existente
//        Crunchyroll archivoExistente = MeterObjeto.leerArchivo();
//
//        // Agregar nuevos datos a la categoría correspondiente (gore o shonen)
//        Categoria categoria = archivoExistente.getCategoria();
//
//        // Crear un nuevo anime para la categoría "shonen"
//        Shonen shonen = categoria.getShonen();
//        Anime nuevoAnimeShonen = new Anime();
//        nuevoAnimeShonen.setTitulo("Nanatsu no Taizai");
//        nuevoAnimeShonen.setAutor("Nakaba Suzuki");
//        nuevoAnimeShonen.setCodigo("99");
//
//        Meses mesesShonen = new Meses();
//        mesesShonen.setEnero(500);
//        mesesShonen.setFebrero(600);
//        mesesShonen.setMarzo(430);
//        mesesShonen.setAbril(300);
//        mesesShonen.setMayo(480);
//        mesesShonen.setJunio(520);
//        mesesShonen.setJulio(620);
//        mesesShonen.setAgosto(700);
//        mesesShonen.setSeptiembre(600);
//        mesesShonen.setOctubre(630);
//        mesesShonen.setNoviembre(650);
//        mesesShonen.setDiciembre(700);
//        // Configurar otros datos de meses según sea necesario
//        Espectadores espectadoresShonen = new Espectadores();
//        espectadoresShonen.setMeses(mesesShonen);
//        nuevoAnimeShonen.setEspectadores(espectadoresShonen);
//
//        // Agregar el nuevo anime Shonen a la lista de animes existentes
//        shonen.getAnimeList().add(nuevoAnimeShonen);
//
//        // Crear un nuevo anime para la categoría "gore"
//        Gore gore = categoria.getGore();
//        Anime nuevoAnimeGore = new Anime();
//        nuevoAnimeGore.setTitulo("Parasyte");
//        nuevoAnimeGore.setAutor("Hitoshi Iwaaki");
//        nuevoAnimeGore.setCodigo("98");
//
//        Meses mesesGore = new Meses();
//        mesesGore.setEnero(700);
//        mesesGore.setFebrero(800);
//        mesesGore.setMarzo(630);
//        mesesGore.setAbril(500);
//        mesesGore.setMayo(480);
//        mesesGore.setJunio(620);
//        mesesGore.setJulio(720);
//        mesesGore.setAgosto(900);
//        mesesGore.setSeptiembre(800);
//        mesesGore.setOctubre(630);
//        mesesGore.setNoviembre(650);
//        mesesGore.setDiciembre(700);
//        // Configurar otros datos de meses según sea necesario
//        Espectadores espectadoresGore = new Espectadores();
//        espectadoresGore.setMeses(mesesGore);
//        nuevoAnimeGore.setEspectadores(espectadoresGore);
//
//        // Agregar el nuevo anime Gore a la lista de animes existentes
//        gore.getAnimeList().add(nuevoAnimeGore);
//
//        // Escribir el archivo actualizado
//        MeterObjeto.escribirArchivo(archivoExistente);
	}

}
